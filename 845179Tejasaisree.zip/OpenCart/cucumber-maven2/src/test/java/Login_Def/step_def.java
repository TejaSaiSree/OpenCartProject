package Login_Def;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import PomPages.LoginPage;
import PomPages.RegisterPage;
import Utiles.ExplicitCode;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excel_utilities.getexcel;

public class step_def extends getexcel {
	WebDriver dr;

	LoginPage h = new LoginPage(dr);
	RegisterPage p = new RegisterPage(dr);
	ExplicitCode e = new ExplicitCode();
	getexcel g = new getexcel();

	@Given("^launch the browser$")
	public void launch_the_browser() throws Throwable {
		g.getExcel("Sheet1");
		e.launchbrowser("chrome");
		
	}

	@When("^login with the valid details(\\d+)$")
	public void login_with_the_valid_details(int arg1) throws Throwable {
		int row = arg1;
		String fname = testdata[row][0];
		String lname = testdata[row][1];
		String email = testdata[row][2];
		String tele = testdata[row][3];
		int g = tele.length();
		String k = tele.substring(1, g - 1);
		String password = testdata[row][4];

		h.Login(email, password);
	}

	@Then("^verify the success login$")
	public void verify_the_success_login() throws Throwable {
		String i = p.myaccount();
		if (i.contains("My")) {
			System.out.println("sucessful login");
		} else {
			System.out.println("unsucessful login");
		}
//		dr.close();
	}

}
