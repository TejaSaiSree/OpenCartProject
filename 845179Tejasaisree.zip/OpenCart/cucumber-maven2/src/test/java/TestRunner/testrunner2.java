package TestRunner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="src\\main\\resources\\Feature1",glue="Register_Def")
public class testrunner2 extends AbstractTestNGCucumberTests{

}
